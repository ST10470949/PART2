import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class QuickChatGUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;

    private JTextField phoneField, recipientField, messageCountField;
    private JTextArea messageArea, sentMessageDisplay;
    private JLabel statusLabel, messageCountLabel, hashLabel, ticksLabel, messageIdLabel;

    private String userPhone;
    private int messageCount;
    private int messageNumber = 1;

    private Map<String, Integer> recipientMessageCount = new HashMap<>();

    public QuickChatGUI() {
        setTitle("Quick Chat");
        setSize(520, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBackground(Color.WHITE);

        addWelcomeScreen();
        addPhoneEntryScreen();
        addMessageCountScreen();
        addChatScreen();

        add(mainPanel);
        cardLayout.show(mainPanel, "welcome");
        setVisible(true);
    }

    private void addWelcomeScreen() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);

        JLabel welcomeLabel = new JLabel("Welcome to Quick Chat", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.GREEN);

        JButton okButton = new JButton("Continue with your chat");
        styleButton(okButton);
        okButton.addActionListener(e -> cardLayout.show(mainPanel, "phone"));

        panel.add(welcomeLabel, BorderLayout.CENTER);
        panel.add(okButton, BorderLayout.SOUTH);

        mainPanel.add(panel, "welcome");
    }

    private void addPhoneEntryScreen() {
        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel label = new JLabel("Enter your SA number (+27XXXXXXXXX):");
        label.setForeground(Color.GREEN);

        phoneField = new JTextField("+27");

        JButton validateButton = new JButton("Please start your chat");
        styleButton(validateButton);
        validateButton.addActionListener(e -> validatePhoneNumber());

        panel.add(label);
        panel.add(phoneField);
        panel.add(validateButton);

        mainPanel.add(panel, "phone");
    }

    private void validatePhoneNumber() {
        String phone = phoneField.getText().trim();

        if (!phone.matches("\\+27\\d{9}")) {
            JOptionPane.showMessageDialog(this, "Invalid format. Use +27 followed by 9 digits.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (isPhoneNumberRegistered(phone)) {
            userPhone = phone;
            JOptionPane.showMessageDialog(this, "Your number is validated!");
            cardLayout.show(mainPanel, "messageCount");
        } else {
            JOptionPane.showMessageDialog(this, "Please enter the phone number you registered with!!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean isPhoneNumberRegistered(String phone) {
        try (Scanner scanner = new Scanner(new File("users.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[2].equals(phone)) {
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "User file not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    private void addMessageCountScreen() {
        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel label = new JLabel("How many messages would you like to send?");
        label.setForeground(Color.GREEN);

        messageCountField = new JTextField();

        JButton proceedButton = new JButton("Start Chat");
        styleButton(proceedButton);
        proceedButton.addActionListener(e -> {
            try {
                int count = Integer.parseInt(messageCountField.getText().trim());
                if (count > 0) {
                    messageCount = count;
                    messageCountLabel.setText("Messages left: " + messageCount);
                    cardLayout.show(mainPanel, "chat");
                } else {
                    JOptionPane.showMessageDialog(this, "Please enter a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(label);
        panel.add(messageCountField);
        panel.add(proceedButton);

        mainPanel.add(panel, "messageCount");
    }

    private void addChatScreen() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        messageCountLabel = new JLabel("Messages left: ");
        messageCountLabel.setForeground(Color.GREEN);

        recipientField = new JTextField("+27");
        messageArea = new JTextArea(4, 30);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);

        JLabel recipientLabel = new JLabel("Recipient's Number (+27XXXXXXXXX):");
        recipientLabel.setForeground(Color.GREEN);

        JLabel messageLabel = new JLabel("Your Message (max 250 characters):");
        messageLabel.setForeground(Color.GREEN);

        JButton sendButton = new JButton("Send");
        styleButton(sendButton);

        JButton showMessagesButton = new JButton("Show Recently Sent Messages");
        styleButton(showMessagesButton);
        showMessagesButton.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Coming Soon!!", "Feature Info", JOptionPane.INFORMATION_MESSAGE)
        );

        JButton quitButton = new JButton("Quit");
        styleButton(quitButton);

        sendButton.addActionListener(e -> handleMessage("send"));
        quitButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Goodbye", "Exit", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        });

        statusLabel = new JLabel("");
        statusLabel.setForeground(Color.GREEN);

        hashLabel = new JLabel("");
        hashLabel.setForeground(Color.GREEN);

        messageIdLabel = new JLabel("");
        messageIdLabel.setForeground(Color.GREEN);

        ticksLabel = new JLabel("");
        ticksLabel.setForeground(Color.BLUE);

        sentMessageDisplay = new JTextArea(4, 30);
        sentMessageDisplay.setEditable(false);
        sentMessageDisplay.setBackground(new Color(240, 255, 240)); // light green background
        sentMessageDisplay.setBorder(BorderFactory.createTitledBorder("Sent Message Info"));

        panel.add(messageCountLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(recipientLabel);
        panel.add(recipientField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(messageLabel);
        panel.add(new JScrollPane(messageArea));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(sendButton);
        buttonPanel.add(showMessagesButton);
        buttonPanel.add(quitButton);

        panel.add(Box.createVerticalStrut(10));
        panel.add(buttonPanel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(statusLabel);
        panel.add(messageIdLabel);
        panel.add(hashLabel);
        panel.add(ticksLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(sentMessageDisplay);

        mainPanel.add(panel, "chat");
    }

    private void handleMessage(String action) {
        if (action.equals("disregard")) {
            clearFields();
            statusLabel.setText("Message disregarded.");
            return;
        }

        if (messageCount <= 0) {
            statusLabel.setText("No messages left.");
            return;
        }

        String recipient = recipientField.getText().trim();
        String message = messageArea.getText().trim();

        if (!recipient.matches("\\+27\\d{9}")) {
            statusLabel.setText("Invalid recipient number.");
            return;
        }

        if (message.isEmpty()) {
            statusLabel.setText("Message cannot be empty.");
            return;
        }

        if (message.length() > 250) {
            statusLabel.setText("Message must be 250 characters or less.");
            return;
        }

        String messageId = generateTenDigitId();
        String firstTwoDigits = messageId.substring(0, 2);
        String[] words = message.split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String hash = (firstTwoDigits + ":" + messageNumber + ":" + firstWord + "_" + lastWord).toUpperCase();

        messageCount--;
        messageCountLabel.setText("Messages left: " + messageCount);
        statusLabel.setText("Message sent to " + recipient + "!");
        messageIdLabel.setText("Message ID: " + messageId);
        hashLabel.setText("Message Hash: " + hash);
        ticksLabel.setText("<html><span style='color:black;'>✔ Sent&nbsp;&nbsp;&nbsp;✔✔ Delivered</span>&nbsp;&nbsp;&nbsp;<span style='color:blue;'>✔✔ Seen</span></html>");

        recipientMessageCount.put(recipient, recipientMessageCount.getOrDefault(recipient, 0) + 1);
        int sentCount = recipientMessageCount.get(recipient);

        sentMessageDisplay.setText(
            "Sent by: " + userPhone +
            "\nTo: " + recipient +
            "\nMessage: " + message +
            "\nMessages sent to this recipient: " + sentCount
        );

        JOptionPane.showMessageDialog(this, "Message has been sent successfully");

        storeMessageInTextFile(recipient, message, messageId, hash);

        // ✅ NEW: Save to JSON
        saveMessageToJson(recipient, message, Integer.parseInt(messageId), hash, new Date().toString());

        int choice = JOptionPane.showOptionDialog(this,
                "What would you like to do next?",
                "Next Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Send Another Message", "Disregard", "Store Message to send later"},
                "Send Another");

        if (choice == 1) {
            statusLabel.setText("Message disregarded.");
            clearFields();
        } else if (choice == 2) {
            statusLabel.setText("Message stored for later.");
            clearFields();
        } else {
            messageNumber++;
            clearFields();
        }
    }

    private void saveMessageToJson(String recipient, String message, int messageID, String messageHash, String timestamp) {
        String jsonMessage = "{\n"
                + "  \"recipient\": \"" + recipient + "\",\n"
                + "  \"message\": \"" + message + "\",\n"
                + "  \"message_id\": " + messageID + ",\n"
                + "  \"message_hash\": \"" + messageHash + "\",\n"
                + "  \"timestamp\": \"" + timestamp + "\"\n"
                + "}";

        try (FileWriter writer = new FileWriter("stored_messages.json", true)) {
            writer.write(jsonMessage + ",\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "❌ Error saving message to JSON!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void storeMessageInTextFile(String recipient, String message, String messageId, String hash) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("storedsent_messages.txt", true))) {
            writer.write("Sender: " + userPhone + "\n");
            writer.write("Recipient: " + recipient + "\n");
            writer.write("Message ID: " + messageId + "\n");
            writer.write("Hash: " + hash + "\n");
            writer.write("Message: " + message + "\n");
            writer.write("---\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving message to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String generateTenDigitId() {
        Random rand = new Random();
        long number = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return Long.toString(number);
    }

    private void clearFields() {
        recipientField.setText("+27");
        messageArea.setText("");
        hashLabel.setText("");
        messageIdLabel.setText("");
        ticksLabel.setText("");
        sentMessageDisplay.setText("");
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(50, 205, 50));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 12));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(QuickChatGUI::new);
    }
}
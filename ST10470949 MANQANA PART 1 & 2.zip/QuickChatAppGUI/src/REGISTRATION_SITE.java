import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class REGISTRATION_SITE extends JFrame {
    private JTextField nameField, surnameField, usernameField, phoneField;
    private JPasswordField passwordField;
    private JButton registerButton, loginButton, quitButton;

    private final Color limeGreen = new Color(50, 205, 50);
    private final Color white = Color.WHITE;

    public REGISTRATION_SITE() {
        setTitle("Register");
        setSize(400, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(white);

        JLabel nameLabel = new JLabel("Name:");
        JLabel surnameLabel = new JLabel("Surname:");
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel phoneLabel = new JLabel("Phone Number:");

        // Set label colors
        nameLabel.setForeground(limeGreen);
        surnameLabel.setForeground(limeGreen);
        usernameLabel.setForeground(limeGreen);
        passwordLabel.setForeground(limeGreen);
        phoneLabel.setForeground(limeGreen);

        nameField = new JTextField();
        surnameField = new JTextField();
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        phoneField = new JTextField();

        registerButton = new JButton("Register");
        loginButton = new JButton("Already have an account");
        quitButton = new JButton("Quit");

        // Style buttons
        styleButton(registerButton);
        styleButton(loginButton);
        styleButton(quitButton);

        panel.add(nameLabel);
        panel.add(nameField);

        panel.add(surnameLabel);
        panel.add(surnameField);

        panel.add(usernameLabel);
        panel.add(usernameField);

        panel.add(passwordLabel);
        panel.add(passwordField);

        panel.add(phoneLabel);
        panel.add(phoneField);

        panel.add(registerButton);
        panel.add(loginButton);
        panel.add(new JLabel()); // Spacer
        panel.add(quitButton);

        add(panel);

        registerButton.addActionListener(e -> handleRegister());
        loginButton.addActionListener(e -> {
            this.dispose();
            SwingUtilities.invokeLater(() -> new LOGIN_SITE());
        });
        quitButton.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setBackground(limeGreen);
        button.setForeground(white);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 12));
    }

    private void handleRegister() {
        String name = nameField.getText().trim();
        String surname = surnameField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String phone = phoneField.getText().trim();

        if (name.isEmpty() || surname.isEmpty() || username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidUsername(username)) {
            JOptionPane.showMessageDialog(this, "Username must contain '_' and be no more than 5 characters.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(this, "Password must be at least 8 characters, contain a capital letter, a number, and a special character.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Phone number must start with +27 and be 12 characters long.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (FileWriter fw = new FileWriter("users.txt", true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(username + "," + password + "," + phone);
            bw.newLine();
            JOptionPane.showMessageDialog(this, "Registering Successfully!");
            clearFields();
            this.dispose();
            SwingUtilities.invokeLater(() -> new LOGIN_SITE());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error writing to users.txt", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        nameField.setText("");
        surnameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        phoneField.setText("");
    }

    private boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;

        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }

    private boolean isValidPhone(String phone) {
        return phone.startsWith("+27") && phone.length() == 12;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(REGISTRATION_SITE::new);
    }
}
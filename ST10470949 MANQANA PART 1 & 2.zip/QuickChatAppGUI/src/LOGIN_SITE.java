import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LOGIN_SITE extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton showPasswordButton;
    private boolean isPasswordVisible = false;

    private final Color limeGreen = new Color(50, 205, 50);
    private final Color white = Color.WHITE;

    public LOGIN_SITE() {
        setTitle("Login");
        setSize(350, 220);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBackground(white); // Set panel background to white
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(limeGreen);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(limeGreen);

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        loginButton = new JButton("Login");
        showPasswordButton = new JButton("Show Password");

        styleButton(loginButton);
        styleButton(showPasswordButton);

        panel.add(userLabel);
        panel.add(usernameField);
        panel.add(passLabel);
        panel.add(passwordField);
        panel.add(new JLabel()); // empty
        panel.add(showPasswordButton);
        panel.add(new JLabel()); // empty
        panel.add(loginButton);

        add(panel);

        // Event Listeners
        loginButton.addActionListener(e -> handleLogin());
        showPasswordButton.addActionListener(e -> togglePasswordVisibility());

        // Username validation when user finishes typing
        usernameField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String inputUsername = usernameField.getText().trim();
                if (isValidUsername(inputUsername)) {
                    JOptionPane.showMessageDialog(LOGIN_SITE.this, "Username successfully captured");
                } else {
                    JOptionPane.showMessageDialog(LOGIN_SITE.this, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Password validation when user finishes typing
        passwordField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String inputPassword = new String(passwordField.getPassword());
                if (isValidPassword(inputPassword)) {
                    JOptionPane.showMessageDialog(LOGIN_SITE.this, "Password successfully captured");
                } else {
                    JOptionPane.showMessageDialog(LOGIN_SITE.this, "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setBackground(limeGreen);
        button.setForeground(white);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 12));
    }

    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordField.setEchoChar('●');
            showPasswordButton.setText("Show Password");
        } else {
            passwordField.setEchoChar((char) 0); // Show text
            showPasswordButton.setText("Hide Password");
        }
        isPasswordVisible = !isPasswordVisible;
    }

    private void handleLogin() {
        String inputUsername = usernameField.getText().trim();
        String inputPassword = new String(passwordField.getPassword());

        if (!isValidUsername(inputUsername)) {
            JOptionPane.showMessageDialog(this, "Invalid username. It must contain an underscore (_) and be no more than 5 characters.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidPassword(inputPassword)) {
            JOptionPane.showMessageDialog(this, "Invalid password.\nIt must be at least 8 characters, contain a capital letter, a number, and a special character.", "Validation Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean isValid = false;

        try (Scanner scanner = new Scanner(new File("users.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                String[] parts = line.split(",");

                if (parts.length == 3) {
                    String fileUsername = parts[0].trim();
                    String filePassword = parts[1].trim();

                    if (fileUsername.equals(inputUsername) && filePassword.equals(inputPassword)) {
                        isValid = true;
                        break;
                    }
                }
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "users.txt file not found!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (isValid) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            this.dispose();
            SwingUtilities.invokeLater(() -> new QuickChatGUI());
        } else {
            JOptionPane.showMessageDialog(this, "Please enter the correct credentials please!", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;

        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LOGIN_SITE::new);
    }
}